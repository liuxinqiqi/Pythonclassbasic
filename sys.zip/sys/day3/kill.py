#!/usr/bin/python

import os
import signal

os.kill(4768,signal.SIGKILL)
