#!/usr/bin/python

from time import sleep

while True:
    sleep(1)
    print "hello world"
