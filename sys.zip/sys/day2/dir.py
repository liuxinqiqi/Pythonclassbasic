#!/usr/bin/python

import os

print os.listdir('../day1')

print os.path.isdir('../day2')

file_path = os.path.join('test','date')

print file_path
