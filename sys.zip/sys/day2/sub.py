#!/usr/bin/python

import subprocess

subprocess.call(['ls','-l'])
