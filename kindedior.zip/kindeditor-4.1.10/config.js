KindEditor.ready(function(K) {
                K.create('textarea[name=content]',{
                    width:'1500px',
                    height:'500px',
                    uploadJson: '/article/upload/kindeditor',
                });
        });
