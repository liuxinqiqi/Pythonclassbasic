#!/usr/bin/python

import os

print os.getpid()

while True:
    pass
