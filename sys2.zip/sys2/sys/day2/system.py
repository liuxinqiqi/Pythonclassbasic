#!/usr/bin/python
#coding=utf-8

import os

print "system 演示:"

os.system('ls -l')

print "over"

exec("print 'Kitty'")

a = eval("2 + 3")

print a

print "over"
