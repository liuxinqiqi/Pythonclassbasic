#!/usr/bin/python
import sys

print "hello world",

sys.stdout.flush()

while True:
    pass
